"""
Standalone Launcher for Range Mean-Reversion Maker Daemon v2.1 with Dynamic Chop Screener.
Runs independently or alongside Trend Engine v2.1/v3.0.

Usage:
    python v2_1/run_range_daemon.py [--capital 300.0] [--risk 0.0075] [--poll 15] [--single-pass]
"""

import argparse
from decimal import Decimal
import logging
from pathlib import Path
import sys

REPO_ROOT = Path(__file__).resolve().parent.parent
BASE_DIR = Path(__file__).resolve().parent
for p in [str(REPO_ROOT), str(BASE_DIR)]:
    if p not in sys.path:
        sys.path.insert(0, p)

from v2_1.src.range_trader_daemon import RangeTraderDaemon

# Configure UTF-8 for Windows consoles
if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    except Exception:
        pass

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] [%(name)s] %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger("RunRangeDaemon")


def main():
    parser = argparse.ArgumentParser(
        description="Launch Range Mean-Reversion Maker Daemon with Integrated Dynamic Chop Screener"
    )
    parser.add_argument("--capital", type=float, default=300.0, help="Initial capital in USDT (default: 300.0)")
    parser.add_argument("--risk", type=float, default=0.0075, help="Risk per trade (default: 0.0075 = 0.75%%)")
    parser.add_argument("--max-pos", type=int, default=2, help="Max concurrent range positions (default: 2)")
    parser.add_argument("--poll", type=int, default=15, help="Polling interval in seconds (default: 15)")
    parser.add_argument("--single-pass", action="store_true", help="Execute single step iteration and print status")
    args = parser.parse_args()

    logger.info("Initializing Range Mean-Reversion Maker Daemon...")
    daemon = RangeTraderDaemon(
        initial_capital=Decimal(str(args.capital)),
        risk_per_trade_pct=Decimal(str(args.risk)),
        max_concurrent_positions=args.max_pos,
    )

    if args.single_pass:
        logger.info("Executing single pass...")
        status = daemon.step_iteration()
        logger.info(
            f"Pass complete. Equity: ${status.get('realized_equity', 0):.2f}, "
            f"Chop Universe: {status.get('active_screened_chop_universe', [])}, "
            f"Orders: {len(status.get('pending_orders', []))}"
        )
    else:
        daemon.run(poll_interval_sec=args.poll)


if __name__ == "__main__":
    main()
