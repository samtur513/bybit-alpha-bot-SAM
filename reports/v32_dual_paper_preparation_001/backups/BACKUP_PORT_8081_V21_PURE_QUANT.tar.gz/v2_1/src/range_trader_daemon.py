"""
Standalone Range Mean-Reversion Maker Daemon with Integrated Dynamic Chop Screener.
Runs independently or alongside Trend Engine v2.1/v3.0 without mutual interference:
1. Dynamic Universe: Scans 800+ Bybit linear perpetuals via ChopUniverseScreener.
2. Conflict Avoidance: Excludes all active Trend symbols (exclude_symbols).
3. Production Execution: Maker Limit orders at BB lower/upper, TP at SMA20 / opposite band.
4. Risk Management: 0.75% risk, 1.5x max position leverage, 4h Time-Stop, 7.0% Hard Circuit Breaker.
5. Live Persistence: Writes state and telemetry to reports/RANGE_LIVE_STATUS.json.
"""

from datetime import datetime, timezone
from decimal import Decimal
import json
import logging
import os
from pathlib import Path
import threading
import time
from typing import Any, Dict, List, Optional, Set, Tuple

import numpy as np
import pandas as pd

from .bybit_client import BybitClient
from .config import (
    BASE_MAKER_FEE,
    BASE_TAKER_FEE,
    BASE_SLIPPAGE,
    REPORTS_DIR,
    CHOP_SCREENER_MIN_TURNOVER,
    CHOP_SCREENER_MAX_KER,
    CHOP_SCREENER_MIN_BW_PCT,
    CHOP_SCREENER_TOP_N,
    CHOP_SCREENER_INTERVAL_HOURS,
)
from .range_engine import RangeMeanReversionEngine, RangeLimitOrder, RangeActivePosition
from .regime_classifier import MarketRegimeClassifier, RegimeData
from .chop_screener import ChopUniverseScreener, ChopScreenerConfig, ChopCandidateMetric
from .persistence import atomic_json

logger = logging.getLogger("RangeTraderDaemon")


class RangeTraderDaemon:
    """
    Autonomous Paper/Live Trading Daemon for Range Mean-Reversion.
    Uses ChopUniverseScreener to continuously discover fresh high-expectancy range coins.
    """

    def __init__(
        self,
        initial_capital: Decimal = Decimal("300.0"),
        risk_per_trade_pct: Decimal = Decimal("0.0075"),
        max_concurrent_positions: int = 2,
        client: Optional[BybitClient] = None,
        exclude_trend_symbols: Optional[Set[str]] = None,
        status_file: Optional[Path] = None,
    ):
        self.client = client or BybitClient()
        self.exclude_trend_symbols = set(exclude_trend_symbols or [])
        self.status_file = status_file or (REPORTS_DIR / "RANGE_LIVE_STATUS.json")
        self.lock = threading.Lock()
        self.running = False

        # 1. Initialize Chop Screener
        screener_cfg = ChopScreenerConfig(
            min_turnover_24h=CHOP_SCREENER_MIN_TURNOVER,
            max_ker=CHOP_SCREENER_MAX_KER,
            min_bandwidth_pct=CHOP_SCREENER_MIN_BW_PCT,
            top_n=CHOP_SCREENER_TOP_N,
            rescan_interval_hours=CHOP_SCREENER_INTERVAL_HOURS,
        )
        self.screener = ChopUniverseScreener(screener_cfg)

        # 2. Initialize Upgraded Range Engine
        self.engine = RangeMeanReversionEngine(
            initial_capital=initial_capital,
            risk_per_trade_pct=risk_per_trade_pct,
            max_concurrent_positions=max_concurrent_positions,
            max_position_leverage=Decimal("1.5"),
            maker_fee=BASE_MAKER_FEE,
            taker_fee=BASE_TAKER_FEE,
            slippage=BASE_SLIPPAGE,
            sl_atr_mult=Decimal("1.2"),
            trend_aligned_only=True,
            max_hold_bars=4,            # 4-hour time stop
            ker_filter_enabled=True,
            max_ker=0.20,
            use_dynamic_slippage=True,
            enable_circuit_breaker=True,
            circuit_breaker_dd_pct=Decimal("7.0"),
        )
        self.classifier = MarketRegimeClassifier()

        self.current_screened_symbols: List[str] = []
        self.last_rescan_ts: float = 0.0
        self.cached_bars_dict: Dict[str, Dict[str, Any]] = {}
        self.cached_regimes_dict: Dict[str, RegimeData] = {}
        self.last_bar_fetch_ts: float = 0.0
        self.bar_cache_ttl_sec: float = 60.0

    def sync_with_trend_state(self, state_files: Optional[List[Path]] = None) -> Set[str]:
        """
        Auto-discovers and excludes symbols actively monitored or traded by Trend Engines (v2.1 / v3).
        Guarantees zero conflict and dual-alpha synergy without requiring inter-process locks.
        """
        if state_files is None:
            repo_root = Path(__file__).resolve().parent.parent.parent
            state_files = [
                REPORTS_DIR / "BOT_STATE_PERSISTENT_V21.json",
                REPORTS_DIR / "PAPER_TRADING_LIVE_V21.json",
                repo_root / "v3" / "reports" / "BOT_STATE_PERSISTENT_V3.json",
                repo_root / "v3" / "reports" / "PAPER_TRADING_LIVE_V3.json",
                repo_root / "reports" / "BOT_STATE_PERSISTENT.json",
            ]

        discovered_trend_symbols: Set[str] = set()
        for p in state_files:
            if not p.exists():
                continue
            try:
                content = p.read_text(encoding="utf-8")
                if not content.strip():
                    continue
                data = json.loads(content)
                # 1. Open positions in trend engine
                for s in data.get("open_positions", {}).keys():
                    discovered_trend_symbols.add(str(s))
                # 2. Monitored radar coins
                for s in data.get("radar", {}).keys():
                    discovered_trend_symbols.add(str(s))
                # 3. Screened / active trend universe
                for item in data.get("screened_universe", []):
                    if isinstance(item, dict) and "symbol" in item:
                        discovered_trend_symbols.add(str(item["symbol"]))
                    elif isinstance(item, str):
                        discovered_trend_symbols.add(item)
            except Exception as e:
                logger.debug(f"Could not parse trend state {p}: {e}")

        if discovered_trend_symbols:
            with self.lock:
                new_symbols = discovered_trend_symbols - self.exclude_trend_symbols
                if new_symbols:
                    self.exclude_trend_symbols.update(new_symbols)
                    logger.info(
                        f"Auto-synced with Trend state: Excluded {len(new_symbols)} new trend symbols "
                        f"(Total excluded: {len(self.exclude_trend_symbols)})"
                    )

        return self.exclude_trend_symbols

    def update_excluded_trend_symbols(self, symbols: Set[str]) -> None:
        """Thread-safe update of symbols currently claimed by Trend engine."""
        with self.lock:
            self.exclude_trend_symbols = set(symbols)
            logger.info(f"Updated excluded trend symbols: {len(self.exclude_trend_symbols)} coins.")

    def run_screener_pass(self) -> List[str]:
        """Runs universe screener and refreshes active chop universe."""
        with self.lock:
            active_trend = set(self.exclude_trend_symbols)
        
        candidates = self.screener.scan_chop_universe(exclude_symbols=active_trend)
        new_symbols = [c.symbol for c in candidates]
        self.current_screened_symbols = new_symbols
        self.last_rescan_ts = time.time()
        logger.info(f"Dynamic Screener found {len(new_symbols)} pure chop coins: {new_symbols}")
        return new_symbols

    def fetch_market_state(
        self, symbols: List[str], force_refresh: bool = False
    ) -> Tuple[Dict[str, Dict[str, Any]], Dict[str, RegimeData]]:
        """Fetches 1h candles for screened symbols and computes regime data with 60s cache."""
        now = time.time()
        if not force_refresh and self.cached_bars_dict and (now - self.last_bar_fetch_ts < self.bar_cache_ttl_sec):
            if all(s in self.cached_bars_dict for s in symbols) and "BTCUSDT" in self.cached_bars_dict:
                return self.cached_bars_dict, self.cached_regimes_dict

        bars_dict = {}
        regimes_dict = {}

        # Always include BTC for trend alignment check
        eval_symbols = list(set(symbols + ["BTCUSDT"]))

        for sym in eval_symbols:
            klines = self.screener.fetch_hourly_klines(sym, limit=35)
            if not klines or len(klines["close"]) < 25:
                if sym in self.cached_bars_dict:
                    bars_dict[sym] = self.cached_bars_dict[sym]
                    regimes_dict[sym] = self.cached_regimes_dict[sym]
                continue

            closes = klines["close"]
            highs = klines["high"]
            lows = klines["low"]
            volumes = klines["volume"]

            b = {
                "open": klines["open"][-1],
                "high": highs[-1],
                "low": lows[-1],
                "close": closes[-1],
                "volume": volumes[-1],
            }
            bars_dict[sym] = b

            df = pd.DataFrame(klines)
            df_ind = self.classifier.prepare_indicators(df)
            last_row = df_ind.iloc[-1]

            reg = self.classifier.classify_bar(
                symbol=sym,
                adx=float(last_row["adx"]),
                bb_mid=float(last_row["bb_mid"]),
                bb_upper=float(last_row["bb_upper"]),
                bb_lower=float(last_row["bb_lower"]),
                bb_width_pctl=float(last_row["bb_width_pctl"]),
                kc_upper=float(last_row["kc_upper"]),
                kc_lower=float(last_row["kc_lower"]),
                rsi=float(last_row["rsi"]),
                atr=float(last_row["atr"]),
                volume=float(last_row["volume"]),
                volume_sma=float(last_row["volume_sma"]),
                ker=float(last_row.get("ker", 0.5)),
            )
            regimes_dict[sym] = reg

        self.cached_bars_dict = bars_dict
        self.cached_regimes_dict = regimes_dict
        self.last_bar_fetch_ts = now
        return bars_dict, regimes_dict

    def step_iteration(self) -> Dict[str, Any]:
        """Single execution cycle of the Range Trader Daemon."""
        # Step 0: Auto-sync excluded trend symbols from live trend engine states
        self.sync_with_trend_state()

        now = time.time()
        # Rescan universe every 4 hours or on first run
        if not self.current_screened_symbols or (now - self.last_rescan_ts >= CHOP_SCREENER_INTERVAL_HOURS * 3600):
            self.run_screener_pass()

        if not self.current_screened_symbols:
            logger.warning("No chop coins found. Will retry next interval.")
            return {"status": "NO_COINS"}

        bars_dict, regimes_dict = self.fetch_market_state(self.current_screened_symbols)
        if not bars_dict:
            return {"status": "NO_BARS"}

        # Determine BTC trend status
        btc_bar = bars_dict.get("BTCUSDT")
        btc_bullish = True
        btc_bearish = True
        if btc_bar:
            btc_reg = regimes_dict.get("BTCUSDT")
            if btc_reg:
                c = float(btc_bar["close"])
                mid = float(btc_reg.bb_mid)
                btc_bullish = c > mid
                btc_bearish = c < mid

        # Current marks for equity calculation
        current_marks = {s: Decimal(str(b["close"])) for s, b in bars_dict.items()}
        current_eq = self.engine.get_equity(current_marks)

        # Step 1: Manage open positions
        closed = self.engine.manage_positions_on_bar(int(now * 1000), bars_dict, regimes_dict)

        # Step 2: Observe drawdown & Circuit Breaker
        eq = self.engine._observe_drawdown(current_marks)

        # Step 3: Scan and generate orders for screened coins
        with self.lock:
            active_trend = list(self.exclude_trend_symbols)

        orders = self.engine.scan_and_generate_orders(
            timestamp=int(now * 1000),
            bars=bars_dict,
            regimes=regimes_dict,
            btc_bullish=btc_bullish,
            btc_bearish=btc_bearish,
            active_trend_symbols=active_trend,
        )

        status_payload = {
            "timestamp_utc": datetime.now(timezone.utc).isoformat(),
            "realized_equity": float(self.engine.realized_equity),
            "floating_equity": float(eq),
            "peak_equity": float(self.engine.peak_equity),
            "max_drawdown_pct": float(self.engine.max_drawdown_pct),
            "circuit_breaker_tripped": self.engine.circuit_breaker_tripped,
            "open_positions": {
                s: {
                    "dir": "LONG" if p.direction == 1 else "SHORT",
                    "entry_price": float(p.entry_price),
                    "qty": float(p.current_qty),
                    "tp": float(p.take_profit),
                    "sl": float(p.stop_loss),
                }
                for s, p in self.engine.open_positions.items()
            },
            "pending_orders": [
                {
                    "symbol": o.symbol,
                    "dir": "LONG" if o.direction == 1 else "SHORT",
                    "price": float(o.price),
                    "qty": float(o.qty),
                    "tp": float(o.take_profit),
                    "sl": float(o.stop_loss),
                }
                for o in orders
            ],
            "active_screened_chop_universe": self.current_screened_symbols,
            "closed_trades_count": len(self.engine.closed_trades),
        }

        # Write atomic telemetry snapshot
        try:
            self.status_file.parent.mkdir(parents=True, exist_ok=True)
            atomic_json(self.status_file, status_payload)
        except Exception as e:
            logger.error(f"Failed to persist range status: {e}")

        return status_payload

    def run(self, poll_interval_sec: int = 15, max_iterations: Optional[int] = None) -> None:
        """
        Main autonomous execution loop for RangeTraderDaemon.
        Periodically rescans the 400+ Bybit universe, executes Maker limit orders,
        and synchronizes with trend engine state.
        """
        self.running = True
        logger.info(
            f"RangeTraderDaemon started (Poll interval: {poll_interval_sec}s, "
            f"Telemetry: {self.status_file})"
        )
        iterations = 0
        try:
            while self.running and (max_iterations is None or iterations < max_iterations):
                try:
                    self.step_iteration()
                except Exception as e:
                    logger.error(f"Error during daemon iteration {iterations}: {e}", exc_info=True)
                iterations += 1
                if self.running and (max_iterations is None or iterations < max_iterations):
                    time.sleep(poll_interval_sec)
        except KeyboardInterrupt:
            logger.info("RangeTraderDaemon interrupted by user.")
        finally:
            self.running = False
            logger.info("RangeTraderDaemon stopped cleanly.")

    def stop(self) -> None:
        """Signals the daemon loop to stop."""
        self.running = False


if __name__ == "__main__":
    import argparse

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] [%(name)s] %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    parser = argparse.ArgumentParser(description="Range Mean-Reversion Maker Daemon with Dynamic Screener")
    parser.add_argument("--capital", type=float, default=300.0, help="Initial capital in USDT (default: 300.0)")
    parser.add_argument("--risk", type=float, default=0.0075, help="Risk per trade (default: 0.0075 = 0.75%%)")
    parser.add_argument("--max-pos", type=int, default=2, help="Max concurrent positions (default: 2)")
    parser.add_argument("--poll", type=int, default=15, help="Polling interval in seconds (default: 15)")
    parser.add_argument("--single-pass", action="store_true", help="Run a single iteration and exit")
    args = parser.parse_args()

    daemon = RangeTraderDaemon(
        initial_capital=Decimal(str(args.capital)),
        risk_per_trade_pct=Decimal(str(args.risk)),
        max_concurrent_positions=args.max_pos,
    )

    if args.single_pass:
        logger.info("Running single pass of RangeTraderDaemon...")
        payload = daemon.step_iteration()
        print(json.dumps(payload, indent=2))
    else:
        daemon.run(poll_interval_sec=args.poll)
