"""
Unit and integration tests for RangeTraderDaemon and ChopUniverseScreener.
Verifies:
1. Initialization and configuration invariants.
2. Manual and automatic synchronization of excluded trend symbols.
3. Zero-conflict synergy with Trend Engine persistent / live telemetry.
4. Early skipping of Trend-claimed symbols in ChopUniverseScreener (no wasted API calls).
5. Full step iteration, limit order generation, and atomic persistence.
6. Clean loop termination with max_iterations.
"""

from decimal import Decimal
import json
from pathlib import Path
import time
from unittest.mock import MagicMock, patch
import pytest

from v2_1.src.range_trader_daemon import RangeTraderDaemon
from v2_1.src.chop_screener import ChopUniverseScreener, ChopScreenerConfig, ChopCandidateMetric
from v2_1.src.regime_classifier import RegimeData


def test_range_trader_daemon_initialization(tmp_path):
    status_file = tmp_path / "RANGE_STATUS.json"
    daemon = RangeTraderDaemon(
        initial_capital=Decimal("300.0"),
        risk_per_trade_pct=Decimal("0.0075"),
        max_concurrent_positions=2,
        exclude_trend_symbols={"BTCUSDT", "ETHUSDT", "SOLUSDT"},
        status_file=status_file,
    )

    assert daemon.engine.realized_equity == Decimal("300.0")
    assert "BTCUSDT" in daemon.exclude_trend_symbols
    assert daemon.engine.max_hold_bars == 4
    assert daemon.engine.trend_aligned_only is True
    assert daemon.engine.enable_circuit_breaker is True


def test_daemon_updates_excluded_symbols():
    daemon = RangeTraderDaemon()
    daemon.update_excluded_trend_symbols({"AVAXUSDT", "LINKUSDT"})
    assert "AVAXUSDT" in daemon.exclude_trend_symbols
    assert "LINKUSDT" in daemon.exclude_trend_symbols


def test_daemon_auto_syncs_with_trend_state_files(tmp_path):
    """Verifies Range daemon reads live Trend engine files and excludes symbols automatically."""
    trend_state = tmp_path / "PAPER_TRADING_LIVE_V3.json"
    trend_state.write_text(
        json.dumps({
            "open_positions": {
                "SUIUSDT": {"dir": "LONG", "qty": 100},
                "DOGEUSDT": {"dir": "LONG", "qty": 500},
            },
            "radar": {
                "NEARUSDT": {"dist_to_long_pct": 0.5},
                "BTCUSDT": {"dist_to_long_pct": 2.0},
            },
            "screened_universe": [
                {"symbol": "SOLUSDT"},
                {"symbol": "ETHUSDT"},
            ],
        }),
        encoding="utf-8",
    )

    daemon = RangeTraderDaemon()
    synced = daemon.sync_with_trend_state(state_files=[trend_state])

    assert "SUIUSDT" in synced
    assert "DOGEUSDT" in synced
    assert "NEARUSDT" in synced
    assert "SOLUSDT" in synced
    assert "ETHUSDT" in synced
    assert "BTCUSDT" in synced


def test_screener_early_skips_trend_claimed_coins():
    """Verifies ChopUniverseScreener skips REST kline calls for symbols claimed by Trend."""
    screener = ChopUniverseScreener()
    mock_tickers = [
        {"symbol": "BTCUSDT", "turnover24h": "100000000.0", "lastPrice": "90000.0"},
        {"symbol": "ETHUSDT", "turnover24h": "50000000.0", "lastPrice": "3000.0"},
        {"symbol": "CHOP1USDT", "turnover24h": "20000000.0", "lastPrice": "5.0"},
    ]
    screener.fetch_all_bybit_linear_tickers = MagicMock(return_value=mock_tickers)
    screener.fetch_hourly_klines = MagicMock(return_value={
        "open": [5.0] * 35,
        "high": [5.2] * 35,
        "low": [4.8] * 35,
        "close": [5.0] * 35,
        "volume": [1000.0] * 35,
    })

    # Exclude BTCUSDT and ETHUSDT (claimed by Trend)
    excluded = {"BTCUSDT", "ETHUSDT"}
    candidates = screener.scan_chop_universe(exclude_symbols=excluded)

    # fetch_hourly_klines should NOT be called for BTCUSDT or ETHUSDT
    called_symbols = [call[0][0] for call in screener.fetch_hourly_klines.call_args_list]
    assert "BTCUSDT" not in called_symbols
    assert "ETHUSDT" not in called_symbols
    assert "CHOP1USDT" in called_symbols


def test_daemon_step_iteration_end_to_end(tmp_path):
    """Verifies single step iteration fetches state, generates orders, and writes atomic JSON."""
    status_file = tmp_path / "RANGE_STATUS.json"
    daemon = RangeTraderDaemon(
        initial_capital=Decimal("300.0"),
        risk_per_trade_pct=Decimal("0.0075"),
        max_concurrent_positions=2,
        status_file=status_file,
    )

    # Mock candidate discovery
    mock_metric = ChopCandidateMetric(
        symbol="FLATUSDT",
        price=10.0,
        turnover_24h=15_000_000.0,
        open_interest=3_000_000.0,
        funding_rate=-0.0002,
        bandwidth_pct=0.06,
        ker=0.08,
        adx=11.0,
        atr=0.30,
        bb_mid=10.0,
        bb_upper=10.4,
        bb_lower=9.6,
        dist_to_lower_pct=4.0,
        dist_to_upper_pct=4.0,
        chop_score=0.055,
        passed_filters=True,
    )
    daemon.screener.scan_chop_universe = MagicMock(return_value=[mock_metric])

    # Mock market state
    mock_bars = {
        "FLATUSDT": {"open": 10.0, "high": 10.2, "low": 9.8, "close": 9.9, "volume": 5000.0},
        "BTCUSDT": {"open": 90000.0, "high": 90500.0, "low": 89800.0, "close": 90200.0, "volume": 1000.0},
    }
    mock_regimes = {
        "FLATUSDT": daemon.classifier.classify_bar(
            symbol="FLATUSDT",
            adx=11.0,
            bb_mid=10.0,
            bb_upper=10.4,
            bb_lower=9.6,
            bb_width_pctl=0.20,
            kc_upper=10.4,
            kc_lower=9.6,
            rsi=32.0,  # oversold near lower band -> trigger limit buy!
            atr=0.30,
            volume=5000.0,
            volume_sma=5000.0,
            ker=0.08,
        ),
        "BTCUSDT": daemon.classifier.classify_bar(
            symbol="BTCUSDT",
            adx=25.0,
            bb_mid=89000.0,
            bb_upper=91000.0,
            bb_lower=87000.0,
            bb_width_pctl=0.50,
            kc_upper=91000.0,
            kc_lower=87000.0,
            rsi=55.0,
            atr=800.0,
            volume=1000.0,
            volume_sma=1000.0,
            ker=0.45,
        ),
    }

    daemon.fetch_market_state = MagicMock(return_value=(mock_bars, mock_regimes))

    status = daemon.step_iteration()

    assert status["realized_equity"] == 300.0
    assert "FLATUSDT" in status["active_screened_chop_universe"]
    assert status_file.exists()

    saved_data = json.loads(status_file.read_text(encoding="utf-8"))
    assert saved_data["realized_equity"] == 300.0
    assert len(saved_data["pending_orders"]) >= 1
    assert saved_data["pending_orders"][0]["symbol"] == "FLATUSDT"
    assert saved_data["pending_orders"][0]["dir"] == "LONG"


def test_daemon_run_with_max_iterations(tmp_path):
    """Verifies that run() completes cleanly when max_iterations is reached."""
    status_file = tmp_path / "RANGE_STATUS.json"
    daemon = RangeTraderDaemon(status_file=status_file)
    daemon.step_iteration = MagicMock(return_value={})

    daemon.run(poll_interval_sec=0, max_iterations=3)

    assert daemon.step_iteration.call_count == 3
    assert daemon.running is False
