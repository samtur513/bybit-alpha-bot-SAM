"""
Unit tests for Chop Universe Screener Module (v2.1).
Verifies:
1. Liquidity filter gating
2. Exclusion of Trend Screener coins (Zero mutual conflict)
3. Kaufman Efficiency Ratio noise gating
4. Bollinger Bandwidth gating
5. Composite Chop Score ranking
"""

import pytest
from v2_1.src.chop_screener import ChopUniverseScreener, ChopScreenerConfig, ChopCandidateMetric


@pytest.fixture
def screener():
    cfg = ChopScreenerConfig(
        min_turnover_24h=10_000_000.0,
        max_ker=0.20,
        min_bandwidth_pct=0.025,
        max_adx=18.0,
        top_n=3,
    )
    return ChopUniverseScreener(cfg)


def test_screener_excludes_trend_symbols(screener):
    """Coins currently claimed by Trend Screener must be rejected immediately."""
    klines = {
        "open": [100.0] * 30,
        "high": [105.0] * 30,
        "low": [95.0] * 30,
        "close": [100.0] * 30,
        "volume": [1000.0] * 30,
    }
    cand = screener.evaluate_symbol(
        symbol="BTCUSDT",
        price=100.0,
        turnover_24h=50_000_000.0,
        open_interest=10_000_000.0,
        funding_rate=0.0001,
        klines=klines,
        exclude_symbols={"BTCUSDT", "ETHUSDT"},
    )
    assert cand.passed_filters is False
    assert "Trend Screener" in cand.rejection_reason


def test_screener_rejects_trending_coins(screener):
    """Coins with smooth directional trends (high KER) must be rejected."""
    # Monotonic uptrend -> KER = 1.0
    closes = [100.0 + i * 2.0 for i in range(30)]
    klines = {
        "open": closes,
        "high": [c + 1.0 for c in closes],
        "low": [c - 1.0 for c in closes],
        "close": closes,
        "volume": [1000.0] * 30,
    }
    cand = screener.evaluate_symbol(
        symbol="TRENDCOINUSDT",
        price=closes[-1],
        turnover_24h=30_000_000.0,
        open_interest=10_000_000.0,
        funding_rate=0.0001,
        klines=klines,
    )
    assert cand.passed_filters is False
    assert "KER" in cand.rejection_reason


def test_screener_accepts_pure_chop(screener):
    """Coins with oscillating ping-pong motion and wide bandwidth must pass."""
    # Ping-pong oscillation: 100, 106, 100, 106... -> low KER, wide bandwidth
    closes = [100.0 if i % 2 == 0 else 106.0 for i in range(30)]
    klines = {
        "open": closes,
        "high": [c + 1.0 for c in closes],
        "low": [c - 1.0 for c in closes],
        "close": closes,
        "volume": [1000.0] * 30,
    }
    cand = screener.evaluate_symbol(
        symbol="CHOPCOINUSDT",
        price=closes[-1],
        turnover_24h=20_000_000.0,
        open_interest=5_000_000.0,
        funding_rate=-0.0003, # Negative funding bonus
        klines=klines,
    )
    assert cand.passed_filters is True
    assert cand.ker <= 0.20
    assert cand.bandwidth_pct >= 0.025
    assert cand.chop_score > 0.0
