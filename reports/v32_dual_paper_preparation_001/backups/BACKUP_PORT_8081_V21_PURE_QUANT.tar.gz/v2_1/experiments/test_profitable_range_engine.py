"""
Profitable Range Mean-Reversion Experiment:
Tests 4 Quantitative Upgrades:
1. Trend-Aligned Asymmetric Direction (Trade Longs ONLY when BTC is Bullish, Shorts ONLY when BTC is Bearish).
2. Time-Based Stop (Max 4 bars holding if mean-reversion does not materialize).
3. Kaufman Efficiency Ratio (KER < 0.25 filter to eliminate directional bleed).
4. Wider Payoff: TP at SMA20, SL at 1.5 ATR with Time Stop.
"""

from decimal import Decimal
import logging
from pathlib import Path
import sys
import time
from typing import Any, Dict, List, Tuple
import numpy as np
import pandas as pd

REPO_ROOT = Path(__file__).resolve().parent.parent.parent
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from v2_1.src.config import DEFAULT_SYMBOLS
from v2_1.src.regime_classifier import MarketRegimeClassifier
from v2_1.run_range_quantum_backtest import load_and_prepare_universe, compute_metrics

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")


def compute_kaufman_er(series: pd.Series, period: int = 14) -> pd.Series:
    """Kaufman Efficiency Ratio: |Close_t - Close_{t-n}| / Sum(|Close_i - Close_{i-1}|)"""
    change = (series - series.shift(period)).abs()
    volatility = (series - series.shift(1)).abs().rolling(period).sum()
    er = change / volatility.replace(0, np.nan)
    return er.fillna(0.5)


def run_enhanced_range_simulation(
    fast_data: Dict[str, Dict[str, Dict[int, Any]]],
    sorted_ts: List[int],
    classifier: MarketRegimeClassifier,
    trend_aligned_only: bool = True,
    max_hold_bars: int = 4,
    ker_filter_enabled: bool = True,
    ker_threshold: float = 0.25,
    sl_atr_mult: float = 1.2,
    risk_pct: float = 0.0075,
    initial_cap: float = 300.0,
) -> Dict[str, Any]:
    
    maker_fee = 0.000324
    taker_fee = 0.0009
    
    realized_equity = initial_cap
    peak_equity = initial_cap
    max_dd = 0.0
    
    open_positions: Dict[str, Dict[str, Any]] = {}
    pending_orders: Dict[str, Dict[str, Any]] = {}
    closed_trades: List[Dict[str, Any]] = []
    equity_curve: List[Dict[str, Any]] = []
    cooldown_tracker: Dict[Tuple[str, int], int] = {}
    bar_counter = 0

    for i in range(len(sorted_ts) - 1):
        t = sorted_ts[i]
        next_t = sorted_ts[i + 1]
        bar_counter += 1
        
        bars_dict = {}
        next_bars_dict = {}
        regimes_dict = {}

        for sym, fd in fast_data.items():
            if t in fd["close"] and next_t in fd["close"]:
                b_curr = {k: fd[k][t] for k in fd}
                b_next = {"open": fd["open"][next_t], "high": fd["high"][next_t], "low": fd["low"][next_t], "close": fd["close"][next_t]}
                bars_dict[sym] = b_curr
                next_bars_dict[sym] = b_next

                regimes_dict[sym] = classifier.classify_bar(
                    symbol=sym,
                    adx=b_curr["adx"],
                    bb_mid=b_curr["bb_mid"],
                    bb_upper=b_curr["bb_upper"],
                    bb_lower=b_curr["bb_lower"],
                    bb_width_pctl=b_curr["bb_width_pctl"],
                    kc_upper=b_curr["kc_upper"],
                    kc_lower=b_curr["kc_lower"],
                    rsi=b_curr["rsi"],
                    atr=b_curr["atr"],
                    volume=b_curr["volume"],
                    volume_sma=b_curr["volume_sma"],
                )

        if not bars_dict:
            continue

        btc_bar = bars_dict.get("BTCUSDT")
        btc_bullish = True
        btc_bearish = True
        if btc_bar:
            c = float(btc_bar["close"])
            ef = float(btc_bar["ema_fast"])
            es = float(btc_bar["ema_slow"])
            btc_bullish = ef > es and c > ef
            btc_bearish = ef < es and c < ef

        # 1. Fill pending orders
        for sym, order in list(pending_orders.items()):
            if sym not in next_bars_dict:
                continue
            nb = next_bars_dict[sym]
            n_open = nb["open"]
            n_low = nb["low"]
            n_high = nb["high"]

            filled = False
            if order["dir"] == 1:
                if n_low < order["price"] and n_open >= order["price"]:
                    filled = True
            elif order["dir"] == -1:
                if n_high > order["price"] and n_open <= order["price"]:
                    filled = True

            if filled:
                if len(open_positions) < 2:
                    fee = order["qty"] * order["price"] * maker_fee
                    realized_equity -= fee
                    open_positions[sym] = {
                        "symbol": sym,
                        "dir": order["dir"],
                        "entry_price": order["price"],
                        "qty": order["qty"],
                        "sl": order["sl"],
                        "tp": order["tp"],
                        "entry_time": t,
                        "entry_bar": bar_counter,
                        "funding": 0.0,
                    }
            del pending_orders[sym]

        # 2. Manage open positions
        for sym in list(open_positions):
            pos = open_positions[sym]
            if bar_counter <= pos["entry_bar"]:
                continue
            if sym not in bars_dict:
                continue

            b = bars_dict[sym]
            b_open = b["open"]
            b_high = b["high"]
            b_low = b["low"]
            b_close = b["close"]

            direction = pos["dir"]
            sl = pos["sl"]
            tp = pos["tp"]
            bars_held = bar_counter - pos["entry_bar"]

            hit_sl = (b_low <= sl) if direction == 1 else (b_high >= sl)
            hit_tp = (b_high > tp) if direction == 1 else (b_low < tp)
            time_exit = (bars_held >= max_hold_bars)

            # Volatility slippage
            vol_ratio = (b_high - b_low) / b_open if b_open > 0 else 0.01
            slip = 0.0005 + 0.15 * vol_ratio

            if hit_sl and hit_tp:
                hit_tp = False

            if hit_sl:
                fill_p = min(b_open, sl) if direction == 1 else max(b_open, sl)
                exec_p = fill_p * (1.0 - slip * direction)
                fee = pos["qty"] * exec_p * taker_fee
                gross = pos["qty"] * (exec_p - pos["entry_price"]) * direction
                net = gross - fee + pos["funding"]
                realized_equity += (gross - fee)

                closed_trades.append({
                    "symbol": sym, "dir": direction, "net_pnl": net, "reason": "SL",
                    "hold_bars": bars_held, "entry_time": pos["entry_time"], "exit_time": t
                })
                cooldown_tracker[(sym, direction)] = bar_counter + 3
                del open_positions[sym]

            elif hit_tp:
                exec_p = tp
                fee = pos["qty"] * exec_p * maker_fee
                gross = pos["qty"] * (exec_p - pos["entry_price"]) * direction
                net = gross - fee + pos["funding"]
                realized_equity += (gross - fee)

                closed_trades.append({
                    "symbol": sym, "dir": direction, "net_pnl": net, "reason": "TP",
                    "hold_bars": bars_held, "entry_time": pos["entry_time"], "exit_time": t
                })
                cooldown_tracker[(sym, direction)] = bar_counter + 1
                del open_positions[sym]

            elif time_exit:
                # Time Stop: Exit at market close
                exec_p = b_close * (1.0 - slip * direction)
                fee = pos["qty"] * exec_p * taker_fee
                gross = pos["qty"] * (exec_p - pos["entry_price"]) * direction
                net = gross - fee + pos["funding"]
                realized_equity += (gross - fee)

                closed_trades.append({
                    "symbol": sym, "dir": direction, "net_pnl": net, "reason": "TIME_STOP",
                    "hold_bars": bars_held, "entry_time": pos["entry_time"], "exit_time": t
                })
                cooldown_tracker[(sym, direction)] = bar_counter + 2
                del open_positions[sym]

        # 3. Floating equity
        unrealized = 0.0
        for sym, pos in open_positions.items():
            if sym in bars_dict:
                mark = bars_dict[sym]["close"]
                unrealized += pos["qty"] * (mark - pos["entry_price"]) * pos["dir"] - pos["qty"] * mark * maker_fee
        current_equity = realized_equity + unrealized
        if current_equity > peak_equity:
            peak_equity = current_equity
        if peak_equity > 0:
            dd = (peak_equity - current_equity) / peak_equity * 100.0
            if dd > max_dd:
                max_dd = dd
        equity_curve.append({"timestamp": t, "equity": current_equity})

        # 4. Generate orders
        if len(open_positions) >= 2:
            continue

        candidates = []
        for sym, b in bars_dict.items():
            if sym in open_positions:
                continue

            reg = regimes_dict.get(sym)
            if not reg or not reg.allows_range_trading:
                continue

            bb_mid = reg.bb_mid
            bb_up = reg.bb_upper
            bb_lo = reg.bb_lower
            if bb_mid <= 0:
                continue

            bw = (bb_up - bb_lo) / bb_mid
            if bw < 0.018:  # Minimum 1.8% bandwidth
                continue

            atr = reg.atr
            close = b["close"]
            rsi = reg.rsi

            # DIRECTION FILTER:
            # If trend_aligned_only:
            # - When BTC is Bullish: ONLY Long (buy dip)
            # - When BTC is Bearish: ONLY Short (sell overbought spike)
            can_long = btc_bullish if trend_aligned_only else (sym == "BTCUSDT" or not btc_bearish)
            can_short = btc_bearish if trend_aligned_only else (sym == "BTCUSDT" or not btc_bullish)

            # LONG
            if can_long and rsi < 35.0 and close >= bb_lo and (bar_counter >= cooldown_tracker.get((sym, 1), 0)):
                limit_p = bb_lo
                sl = limit_p - sl_atr_mult * atr
                tp = min(bb_mid, limit_p * 1.02)
                stop_dist = limit_p - sl
                if stop_dist > 0 and (tp - limit_p) / limit_p >= 0.010:
                    risk_dollars = current_equity * risk_pct
                    raw_notional = risk_dollars / (stop_dist / limit_p)
                    notional = min(raw_notional, current_equity * 1.5)
                    qty = round(notional / limit_p, 4)
                    if qty > 0 and notional >= 5.0:
                        candidates.append({
                            "symbol": sym, "dir": 1, "price": limit_p, "qty": qty,
                            "sl": sl, "tp": tp, "tms": (35.0 - rsi) * bw
                        })

            # SHORT
            if can_short and rsi > 65.0 and close <= bb_up and (bar_counter >= cooldown_tracker.get((sym, -1), 0)):
                limit_p = bb_up
                sl = limit_p + sl_atr_mult * atr
                tp = max(bb_mid, limit_p * 0.98)
                stop_dist = sl - limit_p
                if stop_dist > 0 and (limit_p - tp) / limit_p >= 0.010:
                    risk_dollars = current_equity * risk_pct
                    raw_notional = risk_dollars / (stop_dist / limit_p)
                    notional = min(raw_notional, current_equity * 1.5)
                    qty = round(notional / limit_p, 4)
                    if qty > 0 and notional >= 5.0:
                        candidates.append({
                            "symbol": sym, "dir": -1, "price": limit_p, "qty": qty,
                            "sl": sl, "tp": tp, "tms": (rsi - 65.0) * bw
                        })

        candidates.sort(key=lambda c: c["tms"], reverse=True)
        for cand in candidates[:(2 - len(open_positions))]:
            pending_orders[cand["symbol"]] = cand

    eq_df = pd.DataFrame(equity_curve)
    final_eq = eq_df["equity"].iloc[-1]
    pnls = [t["net_pnl"] for t in closed_trades]
    wins = [p for p in pnls if p > 0]
    losses = [p for p in pnls if p <= 0]
    wr = len(wins) / len(closed_trades) * 100.0 if closed_trades else 0.0
    pf = sum(wins) / abs(sum(losses)) if losses and sum(losses) != 0 else 999.0

    tp_count = sum(1 for t in closed_trades if t["reason"] == "TP")
    sl_count = sum(1 for t in closed_trades if t["reason"] == "SL")
    time_count = sum(1 for t in closed_trades if t["reason"] == "TIME_STOP")

    return {
        "final_equity": final_eq,
        "net_profit": final_eq - initial_cap,
        "roi_pct": (final_eq - initial_cap) / initial_cap * 100.0,
        "trades": len(closed_trades),
        "win_rate": wr,
        "profit_factor": pf,
        "max_drawdown": max_dd,
        "tp_count": tp_count,
        "sl_count": sl_count,
        "time_count": time_count,
    }


def main():
    fast_data, sorted_ts, classifier = load_and_prepare_universe(DEFAULT_SYMBOLS)

    print("\n[1] Naive Baseline (Static Holding, Any Direction):")
    res1 = run_enhanced_range_simulation(
        fast_data, sorted_ts, classifier,
        trend_aligned_only=False, max_hold_bars=999, sl_atr_mult=1.0
    )
    print(f"    Eq: ${res1['final_equity']:.2f}, Net: ${res1['net_profit']:+.2f}, WR: {res1['win_rate']:.1f}%, PF: {res1['profit_factor']:.2f}, MaxDD: {res1['max_drawdown']:.1f}% (TP:{res1['tp_count']}, SL:{res1['sl_count']})")

    print("\n[2] + Time Stop (Max 4 bars / 4 hours):")
    res2 = run_enhanced_range_simulation(
        fast_data, sorted_ts, classifier,
        trend_aligned_only=False, max_hold_bars=4, sl_atr_mult=1.2
    )
    print(f"    Eq: ${res2['final_equity']:.2f}, Net: ${res2['net_profit']:+.2f}, WR: {res2['win_rate']:.1f}%, PF: {res2['profit_factor']:.2f}, MaxDD: {res2['max_drawdown']:.1f}% (TP:{res2['tp_count']}, SL:{res2['sl_count']}, TimeStop:{res2['time_count']})")

    print("\n[3] + Trend-Aligned Direction ONLY (Long when BTC Bullish, Short when BTC Bearish):")
    res3 = run_enhanced_range_simulation(
        fast_data, sorted_ts, classifier,
        trend_aligned_only=True, max_hold_bars=999, sl_atr_mult=1.2
    )
    print(f"    Eq: ${res3['final_equity']:.2f}, Net: ${res3['net_profit']:+.2f}, WR: {res3['win_rate']:.1f}%, PF: {res3['profit_factor']:.2f}, MaxDD: {res3['max_drawdown']:.1f}% (TP:{res3['tp_count']}, SL:{res3['sl_count']})")

    print("\n[4] + Full Synergy (Trend-Aligned + Time Stop 4h + Payoff 1.2 ATR):")
    res4 = run_enhanced_range_simulation(
        fast_data, sorted_ts, classifier,
        trend_aligned_only=True, max_hold_bars=4, sl_atr_mult=1.2
    )
    print(f"    Eq: ${res4['final_equity']:.2f}, Net: ${res4['net_profit']:+.2f}, WR: {res4['win_rate']:.1f}%, PF: {res4['profit_factor']:.2f}, MaxDD: {res4['max_drawdown']:.1f}% (TP:{res4['tp_count']}, SL:{res4['sl_count']}, TimeStop:{res4['time_count']})")


if __name__ == "__main__":
    main()
