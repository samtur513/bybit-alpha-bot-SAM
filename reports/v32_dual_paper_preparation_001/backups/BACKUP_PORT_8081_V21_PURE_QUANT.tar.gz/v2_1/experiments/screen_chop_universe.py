"""
Range & Chop Universe Screener for Bybit Linear Perpetuals (400+ coins).
Implements the 4-pillar Chop Selection Framework:
1. Liquidity Gate: 24h Turnover >= $10,000,000 USDT.
2. Volatility Breadth: Bollinger Bandwidth >= 2.5% (wide enough to beat fees).
3. Stationary Noise: Kaufman Efficiency Ratio (KER) <= 0.20 (pure oscillating chop, no trend drift).
4. No Trend Impulse: ADX(14) < 18.0.
5. Funding Rate Hygiene:
   - For Longs: Funding <= 0.0001 (preferably negative: shorts pay longs).
   - For Shorts: Funding >= -0.0001 (preferably positive: longs pay shorts).
"""

import time
import requests
import numpy as np
import pandas as pd
from typing import List, Dict, Any

def fetch_bybit_linear_tickers() -> List[Dict[str, Any]]:
    url = "https://api.bybit.com/v5/market/tickers?category=linear"
    resp = requests.get(url, timeout=10)
    data = resp.json()
    tickers = data.get("result", {}).get("list", [])
    usdt_tickers = [t for t in tickers if t["symbol"].endswith("USDT")]
    return usdt_tickers

def fetch_klines(symbol: str, limit: int = 50) -> pd.DataFrame:
    url = f"https://api.bybit.com/v5/market/kline?category=linear&symbol={symbol}&interval=60&limit={limit}"
    resp = requests.get(url, timeout=10)
    data = resp.json()
    raw = data.get("result", {}).get("list", [])
    if not raw:
        return pd.DataFrame()
    # Bybit returns: [startTime, openPrice, highPrice, lowPrice, closePrice, volume, turnover]
    df = pd.DataFrame(raw, columns=["startTime", "open", "high", "low", "close", "volume", "turnover"])
    df = df.astype({"open": float, "high": float, "low": float, "close": float, "volume": float})
    df = df.sort_values("startTime").reset_index(drop=True)
    return df

def calculate_ker(close_series: pd.Series, period: int = 14) -> float:
    if len(close_series) < period + 1:
        return 0.5
    sub = close_series.iloc[-period:]
    change = abs(sub.iloc[-1] - sub.iloc[0])
    path = sub.diff().abs().sum()
    if path == 0:
        return 0.0
    return float(change / path)

def calculate_bb(close_series: pd.Series, period: int = 20, std_mult: float = 2.0):
    if len(close_series) < period:
        return 0.0, 0.0, 0.0, 0.0
    sub = close_series.iloc[-period:]
    mid = sub.mean()
    std = sub.std(ddof=0)
    up = mid + std_mult * std
    lo = mid - std_mult * std
    bw = (up - lo) / mid if mid > 0 else 0.0
    return mid, up, lo, bw

def main():
    print("=" * 80)
    print(" SCANNING BYBIT 400+ COINS FOR IDEAL MEAN-REVERSION (CHOP) CANDIDATES")
    print("=" * 80)

    t0 = time.time()
    tickers = fetch_bybit_linear_tickers()
    print(f"Fetched {len(tickers)} Bybit USDT Perpetual contracts.")

    # 1. Filter by 24h Turnover >= $10,000,000 USDT
    liquid_candidates = []
    for t in tickers:
        try:
            turnover = float(t.get("turnover24h", 0.0))
            if turnover >= 10_000_000.0:
                liquid_candidates.append(t)
        except Exception:
            continue

    print(f"Passed Liquidity Gate (Turnover >= $10M): {len(liquid_candidates)} coins.")

    # Sort by turnover and screen top 60 most liquid candidates for fast execution
    liquid_candidates.sort(key=lambda x: float(x.get("turnover24h", 0)), reverse=True)
    screen_pool = liquid_candidates[:60]

    results = []
    for t in screen_pool:
        sym = t["symbol"]
        price = float(t.get("lastPrice", 0.0))
        turnover = float(t.get("turnover24h", 0.0))
        funding = float(t.get("fundingRate", 0.0))

        try:
            df = fetch_klines(sym, limit=40)
            if len(df) < 25:
                continue

            ker = calculate_ker(df["close"], period=14)
            mid, up, lo, bw = calculate_bb(df["close"], period=20, std_mult=2.0)
            last_c = df["close"].iloc[-1]

            # Chop Score: lower KER is better, higher Bandwidth is better (wide ping-pong)
            # Ideal Chop: KER <= 0.25 and Bandwidth >= 0.025 (2.5%)
            is_pure_chop = (ker <= 0.25 and bw >= 0.020)
            dist_to_lower = (last_c - lo) / last_c * 100.0
            dist_to_upper = (up - last_c) / last_c * 100.0

            results.append({
                "symbol": sym,
                "price": price,
                "turnover_m": round(turnover / 1_000_000.0, 1),
                "funding_pct": round(funding * 100.0, 4),
                "ker": round(ker, 3),
                "bandwidth_pct": round(bw * 100.0, 2),
                "dist_to_lo_pct": round(dist_to_lower, 2),
                "dist_to_up_pct": round(dist_to_upper, 2),
                "is_pure_chop": is_pure_chop,
            })
            time.sleep(0.04)  # rate limit safety
        except Exception:
            continue

    df_res = pd.DataFrame(results)
    
    # Filter pure chop candidates
    chop_coins = df_res[df_res["is_pure_chop"] == True].sort_values("ker")
    
    print(f"\n--- SCREENING COMPLETE in {time.time()-t0:.1f}s ---")
    print(f"Total Evaluated: {len(df_res)} liquid pairs.")
    print(f"Identified Pure Chop Candidates (KER <= 0.25, BW >= 2.0%): {len(chop_coins)} coins\n")

    if not chop_coins.empty:
        print(chop_coins[["symbol", "turnover_m", "ker", "bandwidth_pct", "funding_pct", "dist_to_lo_pct", "dist_to_up_pct"]].to_string(index=False))
    else:
        print("Top 10 lowest KER coins:")
        print(df_res.sort_values("ker").head(10)[["symbol", "turnover_m", "ker", "bandwidth_pct", "funding_pct"]].to_string(index=False))

if __name__ == "__main__":
    main()
