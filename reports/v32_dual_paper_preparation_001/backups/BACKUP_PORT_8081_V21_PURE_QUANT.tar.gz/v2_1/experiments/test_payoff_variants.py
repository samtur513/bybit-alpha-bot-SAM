"""
Search for Positive Mathematical Expectancy in Range Mean-Reversion.
Tests:
1. Target: SMA20 vs Opposite Band (Full Range Swing)
2. Asymmetric Risk/Reward: Target 2.0 ATR, Stop 1.0 ATR
3. Deep Capitulation Entry: RSI < 25 (Long) / RSI > 75 (Short)
4. Trailing Stop after reaching SMA20
"""

from decimal import Decimal
import logging
from pathlib import Path
import sys
import time
from typing import Any, Dict, List, Tuple
import numpy as np
import pandas as pd

REPO_ROOT = Path(__file__).resolve().parent.parent.parent
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from v2_1.src.config import DEFAULT_SYMBOLS
from v2_1.src.regime_classifier import MarketRegimeClassifier
from v2_1.run_range_quantum_backtest import load_and_prepare_universe

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")


def test_payoff_variants(fast_data, sorted_ts, classifier):
    maker_fee = 0.000324
    taker_fee = 0.0009
    
    variants = [
        {"name": "V1: Naive (TP on SMA20, SL 1.0 ATR, RSI 35/65)", "target_mode": "sma20", "rsi_l": 35.0, "rsi_s": 65.0, "sl_atr": 1.0},
        {"name": "V2: Full Range (TP on Opposite Band, SL 1.0 ATR)", "target_mode": "opposite_band", "rsi_l": 35.0, "rsi_s": 65.0, "sl_atr": 1.0},
        {"name": "V3: Deep Capitulation (RSI 25/75, TP on SMA20, SL 1.0 ATR)", "target_mode": "sma20", "rsi_l": 25.0, "rsi_s": 75.0, "sl_atr": 1.0},
        {"name": "V4: Deep Capitulation + Full Range (RSI 25/75, TP on Opposite Band)", "target_mode": "opposite_band", "rsi_l": 25.0, "rsi_s": 75.0, "sl_atr": 1.0},
        {"name": "V5: Asymmetric 2:1 RR (TP 2.0 ATR, SL 1.0 ATR, RSI 30/70)", "target_mode": "atr_2x", "rsi_l": 30.0, "rsi_s": 70.0, "sl_atr": 1.0},
        {"name": "V6: Short-Only Mean Reversion (Overbought spikes during BTC Bearish)", "target_mode": "opposite_band", "rsi_l": 999.0, "rsi_s": 70.0, "sl_atr": 1.0, "short_only": True},
    ]

    for var in variants:
        trades = []
        target_mode = var["target_mode"]
        rsi_l = var["rsi_l"]
        rsi_s = var["rsi_s"]
        sl_atr = var["sl_atr"]
        short_only = var.get("short_only", False)

        for sym, fd in fast_data.items():
            ts_list = [t for t in sorted_ts if t in fd["close"]]
            for i in range(len(ts_list) - 1):
                t = ts_list[i]
                next_t = ts_list[i + 1]

                c = fd["close"][t]
                o = fd["open"][t]
                h = fd["high"][t]
                l = fd["low"][t]
                rsi = fd["rsi"][t]
                bb_lo = fd["bb_lower"][t]
                bb_up = fd["bb_upper"][t]
                bb_mid = fd["bb_mid"][t]
                atr = fd["atr"][t]
                adx = fd["adx"][t]

                if adx >= 20.0 or atr <= 0:
                    continue

                # Check Long
                if not short_only and rsi < rsi_l and c >= bb_lo:
                    limit_p = bb_lo
                    # check fill on next bar
                    n_o = fd["open"][next_t]
                    n_l = fd["low"][next_t]
                    if n_o >= limit_p and n_l < limit_p:
                        # filled Long!
                        entry_p = limit_p
                        sl_p = entry_p - sl_atr * atr
                        if target_mode == "sma20":
                            tp_p = bb_mid
                        elif target_mode == "opposite_band":
                            tp_p = bb_up
                        elif target_mode == "atr_2x":
                            tp_p = entry_p + 2.0 * atr

                        # simulate forward up to 12 bars
                        pnl = 0.0
                        exit_r = "TIMEOUT"
                        for k in range(i + 1, min(i + 15, len(ts_list))):
                            kt = ts_list[k]
                            kh = fd["high"][kt]
                            kl = fd["low"][kt]
                            ko = fd["open"][kt]
                            kc = fd["close"][kt]

                            hit_sl = (kl <= sl_p)
                            hit_tp = (kh >= tp_p)

                            if hit_sl and hit_tp:
                                hit_tp = False
                            if hit_sl:
                                slip = 0.0005 + 0.15 * ((kh - kl) / ko)
                                exec_p = sl_p * (1.0 - slip)
                                pnl = (exec_p - entry_p) / entry_p - maker_fee - taker_fee
                                exit_r = "SL"
                                break
                            elif hit_tp:
                                exec_p = tp_p
                                pnl = (exec_p - entry_p) / entry_p - maker_fee - maker_fee
                                exit_r = "TP"
                                break
                        if exit_r == "TIMEOUT":
                            exec_p = kc
                            slip = 0.0005 + 0.15 * ((kh - kl) / ko)
                            pnl = (exec_p * (1.0 - slip) - entry_p) / entry_p - maker_fee - taker_fee

                        trades.append({"pnl": pnl, "reason": exit_r, "dir": 1})

                # Check Short
                if rsi > rsi_s and c <= bb_up:
                    limit_p = bb_up
                    n_o = fd["open"][next_t]
                    n_h = fd["high"][next_t]
                    if n_o <= limit_p and n_h > limit_p:
                        entry_p = limit_p
                        sl_p = entry_p + sl_atr * atr
                        if target_mode == "sma20":
                            tp_p = bb_mid
                        elif target_mode == "opposite_band":
                            tp_p = bb_lo
                        elif target_mode == "atr_2x":
                            tp_p = entry_p - 2.0 * atr

                        pnl = 0.0
                        exit_r = "TIMEOUT"
                        for k in range(i + 1, min(i + 15, len(ts_list))):
                            kt = ts_list[k]
                            kh = fd["high"][kt]
                            kl = fd["low"][kt]
                            ko = fd["open"][kt]
                            kc = fd["close"][kt]

                            hit_sl = (kh >= sl_p)
                            hit_tp = (kl <= tp_p)
                            if hit_sl and hit_tp:
                                hit_tp = False
                            if hit_sl:
                                slip = 0.0005 + 0.15 * ((kh - kl) / ko)
                                exec_p = sl_p * (1.0 + slip)
                                pnl = (entry_p - exec_p) / entry_p - maker_fee - taker_fee
                                exit_r = "SL"
                                break
                            elif hit_tp:
                                exec_p = tp_p
                                pnl = (entry_p - exec_p) / entry_p - maker_fee - maker_fee
                                exit_r = "TP"
                                break
                        if exit_r == "TIMEOUT":
                            exec_p = kc
                            slip = 0.0005 + 0.15 * ((kh - kl) / ko)
                            pnl = (entry_p - exec_p * (1.0 + slip)) / entry_p - maker_fee - taker_fee

                        trades.append({"pnl": pnl, "reason": exit_r, "dir": -1})

        tot = len(trades)
        if tot > 0:
            pnls = [t["pnl"] for t in trades]
            wins = [p for p in pnls if p > 0]
            losses = [p for p in pnls if p <= 0]
            wr = len(wins) / tot * 100.0
            tot_w = sum(wins)
            tot_l = abs(sum(losses))
            pf = (tot_w / tot_l) if tot_l > 0 else 999.0
            avg_ret = np.mean(pnls) * 100.0
            net_pct = sum(pnls) * 100.0
            tp_count = sum(1 for t in trades if t["reason"] == "TP")
            sl_count = sum(1 for t in trades if t["reason"] == "SL")
            print(f"[{var['name']}]")
            print(f"   Trades: {tot}, WR: {wr:.1f}%, PF: {pf:.2f}, Avg Return/Trade: {avg_ret:+.3f}%, Net Cumulative: {net_pct:+.1f}%, TP:{tp_count}, SL:{sl_count}\n")


if __name__ == "__main__":
    fast_data, sorted_ts, classifier = load_and_prepare_universe(DEFAULT_SYMBOLS)
    test_payoff_variants(fast_data, sorted_ts, classifier)
