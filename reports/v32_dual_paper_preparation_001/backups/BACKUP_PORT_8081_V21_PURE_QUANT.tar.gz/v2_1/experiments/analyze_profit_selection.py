import requests
import sys
import time
import numpy as np

if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    except Exception:
        pass

def main():
    print("=" * 85)
    print("ANALYSIS: MULTI-FACTOR COIN SELECTION FOR MAXIMUM PROFIT IN RANGE/CHOP")
    print("=" * 85)

    url = "https://api.bybit.com/v5/market/tickers?category=linear"
    resp = requests.get(url, timeout=12).json()
    tickers = [t for t in resp.get("result", {}).get("list", []) if t["symbol"].endswith("USDT")]
    liquid = sorted(
        [t for t in tickers if float(t.get("turnover24h", 0)) >= 10_000_000],
        key=lambda t: float(t.get("turnover24h", 0)),
        reverse=True,
    )

    print(f"Total Bybit USDT Perpetuals: {len(tickers)}")
    print(f"Liquid Perpetuals (24h Turnover >= $10M): {len(liquid)}")

    results = []
    # Evaluate top 50 liquid
    for t in liquid[:50]:
        sym = t["symbol"]
        if sym in {"BTCUSDT", "ETHUSDT", "SOLUSDT"}:
            continue

        k_url = f"https://api.bybit.com/v5/market/kline?category=linear&symbol={sym}&interval=60&limit=35"
        try:
            kr = requests.get(k_url, timeout=6).json()
            raw = kr.get("result", {}).get("list", [])
            if len(raw) < 25:
                continue
            candles = sorted(raw, key=lambda c: int(c[0]))
            closes = [float(c[4]) for c in candles]
            highs = [float(c[2]) for c in candles]
            lows = [float(c[3]) for c in candles]

            # 1. Kaufman Efficiency Ratio (KER 14)
            sub = closes[-14:]
            net_c = abs(sub[-1] - sub[0])
            gross = sum(abs(sub[i] - sub[i-1]) for i in range(1, len(sub)))
            ker = (net_c / gross) if gross > 1e-9 else 0.0

            # 2. Bollinger Bandwidth (20, 2.0)
            sub20 = closes[-20:]
            mid = np.mean(sub20)
            std = np.std(sub20, ddof=0)
            bw = (4.0 * std) / mid if mid > 0 else 0.0

            # 3. Wilder ADX
            tr = [max(highs[i]-lows[i], abs(highs[i]-closes[i-1]), abs(lows[i]-closes[i-1])) for i in range(1, len(closes))]
            p_dm = [highs[i]-highs[i-1] if highs[i]-highs[i-1]>0 and highs[i]-highs[i-1]>lows[i-1]-lows[i] else 0.0 for i in range(1, len(closes))]
            m_dm = [lows[i-1]-lows[i] if lows[i-1]-lows[i]>0 and lows[i-1]-lows[i]>highs[i]-highs[i-1] else 0.0 for i in range(1, len(closes))]
            s_tr = np.mean(tr[-14:])
            s_p = np.mean(p_dm[-14:])
            s_m = np.mean(m_dm[-14:])
            p_di = 100 * s_p / s_tr if s_tr > 0 else 0
            m_di = 100 * s_m / s_tr if s_tr > 0 else 0
            adx = 100 * abs(p_di - m_di) / (p_di + m_di) if (p_di + m_di) > 0 else 0

            # 4. Funding rate and Volume
            funding = float(t.get("fundingRate", 0))
            turnover_m = float(t.get("turnover24h", 0)) / 1e6
            oi_m = float(t.get("openInterestValue", 0)) / 1e6

            # 5. Oscillation cycle frequency (SMA20 zero crossings in last 20 bars)
            crosses = sum(1 for i in range(1, len(sub20)) if (sub20[i] - mid) * (sub20[i-1] - mid) < 0)

            results.append({
                "symbol": sym,
                "price": closes[-1],
                "turnover_m": turnover_m,
                "oi_m": oi_m,
                "bw_pct": bw * 100,
                "ker": ker,
                "adx": adx,
                "funding_pct": funding * 100,
                "crosses": crosses,
            })
            time.sleep(0.02)
        except Exception:
            continue

    # Filter for pure chop
    chop_candidates = [r for r in results if r["ker"] <= 0.20 and r["adx"] < 18 and r["bw_pct"] >= 2.5]

    # Calculate Institutional Range Alpha Score (IRAS)
    # Factor A: Bandwidth clearance (Profit Potential)
    # Factor B: Stationarity (1 - KER)^2
    # Factor C: Cycle Velocity (crosses / 10)
    # Factor D: Carry Yield Boost (1 + |funding| * 100)
    for r in chop_candidates:
        f_bw = r["bw_pct"]
        f_purity = (1.0 - r["ker"]) ** 2
        f_velocity = 0.5 + (r["crosses"] / 10.0)
        f_carry = 1.0 + (abs(r["funding_pct"]) * 2.0)
        r["iras_score"] = f_bw * f_purity * f_velocity * f_carry
        # Expected Reward / Risk ratio to middle band:
        # Distance to TP (mid band) ~ BW / 2. Friction ~ 0.065%. Stop loss ~ 1.2 * ATR ~ (BW / 2.5)
        dist_tp = r["bw_pct"] / 2.0
        r["reward_risk_ratio"] = (dist_tp - 0.065) / (dist_tp * 0.7) if dist_tp > 0 else 0.0

    chop_candidates.sort(key=lambda r: r["iras_score"], reverse=True)

    print(f"\nDiscovered {len(chop_candidates)} High-Expectancy Chop Pairs:\n")
    print(f"{'Symbol':<14} | {'Turnover':<9} | {'Bandwidth':<9} | {'KER':<6} | {'ADX':<5} | {'Crosses':<7} | {'Funding':<9} | {'R:R Ratio':<9} | {'IRAS Score':<10}")
    print("-" * 95)
    for r in chop_candidates:
        print(f"{r['symbol']:<14} | ${r['turnover_m']:>6.1f}M | {r['bw_pct']:>7.2f}% | {r['ker']:>6.3f} | {r['adx']:>5.1f} | {r['crosses']:>7} | {r['funding_pct']:>+8.4f}% | {r['reward_risk_ratio']:>8.2f}:1 | {r['iras_score']:>10.3f}")

if __name__ == "__main__":
    main()
