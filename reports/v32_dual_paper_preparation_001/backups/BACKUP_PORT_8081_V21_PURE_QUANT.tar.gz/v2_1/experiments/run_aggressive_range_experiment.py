"""
Aggressive Range Mean-Reversion Experiment Runner.
Compares:
1. Baseline Conservative Range Engine (block alt buys on sliding BTC, RSI 35/65, 2 slots, cooldown 3)
2. Experiment A: Allow Alt Buys on Sliding BTC (exact user query)
3. Experiment B: Moderate Aggression (Allow Alt Buys + RSI 40/60 + 3 slots + cooldown 2)
4. Experiment C: High Frequency (Allow Alt Buys + RSI 45/55 + 4 slots + cooldown 1)

Evaluates standalone performance, breakdown of Alt Longs on Bearish BTC, and Hybrid Synergy.
"""

from decimal import Decimal
import logging
from pathlib import Path
import sys
import time
from typing import Any, Dict, List, Tuple
import numpy as np
import pandas as pd

REPO_ROOT = Path(__file__).resolve().parent.parent.parent
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from v2_1.src.config import DEFAULT_SYMBOLS
from v2_1.src.core_v2 import CoreV2Engine, ClosedTrade
from v2_1.src.regime_classifier import MarketRegimeClassifier, RegimeData
from v2_1.src.range_engine import RangeMeanReversionEngine, RangeClosedTrade
from v2_1.run_range_quantum_backtest import load_and_prepare_universe, compute_metrics

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("AggressiveRangeExp")


def run_standalone_config(
    fast_data: Dict[str, Dict[str, Dict[int, Any]]],
    sorted_ts: List[int],
    classifier: MarketRegimeClassifier,
    config: Dict[str, Any],
    initial_capital: Decimal = Decimal("300.0"),
) -> Tuple[RangeMeanReversionEngine, pd.DataFrame, List[Dict[str, Any]]]:
    """Runs a single Range Engine configuration and logs trade context."""
    instrument_rules = {
        s: {
            "minOrderQty": Decimal("0.001") if "BTC" in s else Decimal("0.01"),
            "qtyStep": Decimal("0.001") if "BTC" in s else Decimal("0.01"),
            "minNotional": Decimal("5.0"),
            "maxOrderQty": Decimal("1000000"),
        }
        for s in fast_data
    }

    engine = RangeMeanReversionEngine(
        initial_capital=initial_capital,
        instrument_rules=instrument_rules,
        risk_per_trade_pct=config.get("risk_per_trade_pct", Decimal("0.01")),
        max_concurrent_positions=config.get("max_concurrent_positions", 2),
        max_portfolio_leverage=Decimal("3.5"),
        maker_fee=Decimal("0.000324"),
        taker_fee=Decimal("0.0009"),
        slippage=Decimal("0.0002"),
        sl_atr_mult=Decimal("1.0"),
        min_tp_dist_pct=config.get("min_tp_dist_pct", Decimal("0.010")),
        max_tp_dist_pct=config.get("max_tp_dist_pct", Decimal("0.020")),
        cooldown_bars=config.get("cooldown_bars", 3),
        allow_alts_on_btc_bearish=config.get("allow_alts_on_btc_bearish", False),
        allow_alts_on_btc_bullish=config.get("allow_alts_on_btc_bullish", False),
        rsi_long_threshold=config.get("rsi_long_threshold", 35.0),
        rsi_short_threshold=config.get("rsi_short_threshold", 65.0),
        min_bandwidth_pct=config.get("min_bandwidth_pct", Decimal("0.015")),
    )

    equity_records = []
    trade_contexts = []
    btc_bearish_map = {}

    for i in range(len(sorted_ts) - 1):
        t = sorted_ts[i]
        next_t = sorted_ts[i + 1]

        bars_dict = {}
        next_bars_dict = {}
        next_open_prices = {}
        regimes_dict = {}

        for sym, fd in fast_data.items():
            if t in fd["close"] and next_t in fd["close"]:
                b_curr = {k: fd[k][t] for k in fd}
                b_next = {"open": fd["open"][next_t], "high": fd["high"][next_t], "low": fd["low"][next_t], "close": fd["close"][next_t]}
                bars_dict[sym] = b_curr
                next_bars_dict[sym] = b_next
                next_open_prices[sym] = Decimal(str(b_next["open"]))

                regimes_dict[sym] = classifier.classify_bar(
                    symbol=sym,
                    adx=b_curr["adx"],
                    bb_mid=b_curr["bb_mid"],
                    bb_upper=b_curr["bb_upper"],
                    bb_lower=b_curr["bb_lower"],
                    bb_width_pctl=b_curr["bb_width_pctl"],
                    kc_upper=b_curr["kc_upper"],
                    kc_lower=b_curr["kc_lower"],
                    rsi=b_curr["rsi"],
                    atr=b_curr["atr"],
                    volume=b_curr["volume"],
                    volume_sma=b_curr["volume_sma"],
                )

        if not bars_dict:
            continue

        btc_bar = bars_dict.get("BTCUSDT")
        btc_bullish = True
        btc_bearish = True
        if btc_bar:
            c = float(btc_bar["close"])
            ef = float(btc_bar["ema_fast"])
            es = float(btc_bar["ema_slow"])
            btc_bullish = ef > es and c > ef
            btc_bearish = ef < es and c < ef

        btc_bearish_map[t] = btc_bearish

        # Track existing trades before step to identify newly filled
        step_res = engine.step_bar(
            timestamp=t,
            bars=bars_dict,
            next_bars=next_bars_dict,
            next_open_prices=next_open_prices,
            regimes=regimes_dict,
            btc_bullish=btc_bullish,
            btc_bearish=btc_bearish,
        )

        dt = pd.to_datetime(t, unit="ms")
        if dt.hour in (0, 8, 16) and dt.minute == 0:
            current_marks = {s: Decimal(str(b["close"])) for s, b in bars_dict.items()}
            engine.process_funding(t, Decimal("0.0001"), current_marks)

        current_marks = {s: Decimal(str(b["close"])) for s, b in bars_dict.items()}
        eq = float(engine.get_equity(current_marks))
        equity_records.append({"timestamp": t, "equity": eq})

    eq_df = pd.DataFrame(equity_records)

    # Classify trades (whether opened while BTC was bearish)
    for tr in engine.closed_trades:
        was_btc_bearish = btc_bearish_map.get(tr.entry_time, False)
        is_alt = (tr.symbol != "BTCUSDT")
        is_long = (tr.direction == 1)
        is_alt_long_on_btc_bearish = is_alt and is_long and was_btc_bearish
        trade_contexts.append({
            "symbol": tr.symbol,
            "direction": "LONG" if tr.direction == 1 else "SHORT",
            "net_pnl": float(tr.net_pnl),
            "exit_reason": tr.exit_reason,
            "hold_hours": tr.hold_hours,
            "is_alt_long_on_btc_bearish": is_alt_long_on_btc_bearish,
            "btc_bearish_at_entry": was_btc_bearish,
        })

    return engine, eq_df, trade_contexts


def run_hybrid_unified_wallet(
    fast_data: Dict[str, Dict[str, Dict[int, Any]]],
    sorted_ts: List[int],
    classifier: MarketRegimeClassifier,
    range_config: Dict[str, Any],
    initial_capital: Decimal = Decimal("300.0"),
) -> Tuple[List[Any], pd.DataFrame]:
    """
    Runs Dual-Regime Hybrid Engine with a STRICT SINGLE WALLET ($300.00 total deposit).
    Trend risks 2.5% of total wallet equity; Range risks 1.0% of total wallet equity.
    Portfolio aggregate leverage strictly capped at 3.5x.
    """
    instrument_rules = {
        s: {
            "minOrderQty": Decimal("0.001") if "BTC" in s else Decimal("0.01"),
            "qtyStep": Decimal("0.001") if "BTC" in s else Decimal("0.01"),
            "minNotional": Decimal("5.0"),
            "maxOrderQty": Decimal("1000000"),
        }
        for s in fast_data
    }

    # Wallet state
    realized_equity = initial_capital
    peak_equity = initial_capital

    trend_engine = CoreV2Engine(
        initial_capital=initial_capital,
        instrument_rules=instrument_rules,
        base_risk_pct=Decimal("0.025"),
        max_leverage=Decimal("3.5"),
        atr_stop_mult=Decimal("2.5"),
        taker_fee=Decimal("0.0009"),
        slippage=Decimal("0.0002"),
        portfolio_leverage=Decimal("3.5"),
        drawdown_limit_pct=Decimal("45.0"),
        min_adx=20.0,
        cooldown_bars=3,
        enable_btc_delta_filter=True,
    )

    range_engine = RangeMeanReversionEngine(
        initial_capital=initial_capital,
        instrument_rules=instrument_rules,
        risk_per_trade_pct=range_config.get("risk_per_trade_pct", Decimal("0.01")),
        max_concurrent_positions=range_config.get("max_concurrent_positions", 2),
        max_portfolio_leverage=Decimal("3.5"),
        maker_fee=Decimal("0.000324"),
        taker_fee=Decimal("0.0009"),
        slippage=Decimal("0.0002"),
        sl_atr_mult=Decimal("1.0"),
        min_tp_dist_pct=range_config.get("min_tp_dist_pct", Decimal("0.010")),
        max_tp_dist_pct=range_config.get("max_tp_dist_pct", Decimal("0.020")),
        cooldown_bars=range_config.get("cooldown_bars", 3),
        allow_alts_on_btc_bearish=range_config.get("allow_alts_on_btc_bearish", False),
        allow_alts_on_btc_bullish=range_config.get("allow_alts_on_btc_bullish", False),
        rsi_long_threshold=range_config.get("rsi_long_threshold", 35.0),
        rsi_short_threshold=range_config.get("rsi_short_threshold", 65.0),
        min_bandwidth_pct=range_config.get("min_bandwidth_pct", Decimal("0.015")),
    )

    equity_records = []
    all_trades = []

    for i in range(len(sorted_ts) - 1):
        t = sorted_ts[i]
        next_t = sorted_ts[i + 1]

        bars_dict = {}
        next_bars_dict = {}
        next_open_prices = {}
        regimes_dict = {}

        for sym, fd in fast_data.items():
            if t in fd["close"] and next_t in fd["close"]:
                b_curr = {k: fd[k][t] for k in fd}
                b_next = {"open": fd["open"][next_t], "high": fd["high"][next_t], "low": fd["low"][next_t], "close": fd["close"][next_t]}
                bars_dict[sym] = b_curr
                next_bars_dict[sym] = b_next
                next_open_prices[sym] = Decimal(str(b_next["open"]))

                regimes_dict[sym] = classifier.classify_bar(
                    symbol=sym,
                    adx=b_curr["adx"],
                    bb_mid=b_curr["bb_mid"],
                    bb_upper=b_curr["bb_upper"],
                    bb_lower=b_curr["bb_lower"],
                    bb_width_pctl=b_curr["bb_width_pctl"],
                    kc_upper=b_curr["kc_upper"],
                    kc_lower=b_curr["kc_lower"],
                    rsi=b_curr["rsi"],
                    atr=b_curr["atr"],
                    volume=b_curr["volume"],
                    volume_sma=b_curr["volume_sma"],
                )

        if not bars_dict:
            continue

        btc_bar = bars_dict.get("BTCUSDT")
        btc_bullish = True
        btc_bearish = True
        if btc_bar:
            c = float(btc_bar["close"])
            ef = float(btc_bar["ema_fast"])
            es = float(btc_bar["ema_slow"])
            btc_bullish = ef > es and c > ef
            btc_bearish = ef < es and c < ef

        # Harmonize common equity base
        current_marks = {s: Decimal(str(b["close"])) for s, b in bars_dict.items()}
        common_eq = realized_equity
        for s, p in trend_engine.open_positions.items():
            mark = current_marks.get(s, p.entry_price)
            common_eq += p.current_qty * (mark - p.entry_price) * p.direction - p.current_qty * mark * trend_engine.taker_fee
        for s, p in range_engine.open_positions.items():
            mark = current_marks.get(s, p.entry_price)
            common_eq += p.current_qty * (mark - p.entry_price) * p.direction - p.current_qty * mark * range_engine.maker_fee

        trend_engine.realized_equity = max(Decimal("10.0"), common_eq)
        range_engine.realized_equity = max(Decimal("10.0"), common_eq)

        # 1. Step Range Engine
        active_trend_syms = list(trend_engine.open_positions.keys())
        r_step = range_engine.step_bar(
            timestamp=t,
            bars=bars_dict,
            next_bars=next_bars_dict,
            next_open_prices=next_open_prices,
            regimes=regimes_dict,
            btc_bullish=btc_bullish,
            btc_bearish=btc_bearish,
            active_trend_symbols=active_trend_syms,
        )

        for cl in r_step["closed"]:
            realized_equity += cl.net_pnl
            all_trades.append(cl)

        # 2. Step Trend Engine
        trend_bars = {
            s: b for s, b in bars_dict.items()
            if s not in range_engine.open_positions and s not in range_engine.pending_orders
        }
        t_prev_closed_count = len(trend_engine.closed_trades)
        trend_engine.process_bar_event(
            timestamp=t,
            bars=trend_bars,
            next_open_prices=next_open_prices,
            manage_positions=True,
            btc_bullish=btc_bullish,
            btc_bearish=btc_bearish,
        )
        if len(trend_engine.closed_trades) > t_prev_closed_count:
            new_cl = trend_engine.closed_trades[t_prev_closed_count:]
            for cl in new_cl:
                realized_equity += cl.net_pnl
                all_trades.append(cl)

        # 3. Funding
        dt = pd.to_datetime(t, unit="ms")
        if dt.hour in (0, 8, 16) and dt.minute == 0:
            trend_funding = {s: Decimal("0.0001") for s in trend_engine.open_positions}
            trend_engine.process_funding_event(t, trend_funding, current_marks)
            range_engine.process_funding(t, Decimal("0.0001"), current_marks)

        # Total combined mark-to-market equity
        eq = realized_equity
        for s, p in trend_engine.open_positions.items():
            mark = current_marks.get(s, p.entry_price)
            eq += p.current_qty * (mark - p.entry_price) * p.direction - p.current_qty * mark * trend_engine.taker_fee
        for s, p in range_engine.open_positions.items():
            mark = current_marks.get(s, p.entry_price)
            eq += p.current_qty * (mark - p.entry_price) * p.direction - p.current_qty * mark * range_engine.maker_fee

        equity_records.append({"timestamp": t, "equity": float(eq)})

    eq_df = pd.DataFrame(equity_records)
    return all_trades, eq_df


def main():
    print("=" * 80)
    print(" EXPERIMENT: AGGRESSIVE RANGE ENGINE & ALTCOIN BUYS ON SLIDING BTC")
    print("=" * 80)

    fast_data, sorted_ts, classifier = load_and_prepare_universe(DEFAULT_SYMBOLS)

    configs = {
        "Baseline (Conservative)": {
            "allow_alts_on_btc_bearish": False,
            "rsi_long_threshold": 35.0,
            "rsi_short_threshold": 65.0,
            "max_concurrent_positions": 2,
            "cooldown_bars": 3,
        },
        "Exp 1: Allow Alts on Sliding BTC": {
            "allow_alts_on_btc_bearish": True,
            "rsi_long_threshold": 35.0,
            "rsi_short_threshold": 65.0,
            "max_concurrent_positions": 2,
            "cooldown_bars": 3,
        },
        "Exp 2: More Frequent (Alts on BTC Bear + RSI 40/60 + 3 slots)": {
            "allow_alts_on_btc_bearish": True,
            "rsi_long_threshold": 40.0,
            "rsi_short_threshold": 60.0,
            "max_concurrent_positions": 3,
            "cooldown_bars": 2,
        },
        "Exp 3: Hyper-Aggressive (Alts on BTC Bear + RSI 45/55 + 4 slots + cd 1)": {
            "allow_alts_on_btc_bearish": True,
            "rsi_long_threshold": 45.0,
            "rsi_short_threshold": 55.0,
            "max_concurrent_positions": 4,
            "cooldown_bars": 1,
        },
    }

    results = {}
    alt_breakdowns = {}

    for name, cfg in configs.items():
        print(f"\n---> Testing Standalone: {name}...")
        t0 = time.time()
        engine, eq_df, contexts = run_standalone_config(fast_data, sorted_ts, classifier, cfg)
        m = compute_metrics(300.0, float(eq_df["equity"].iloc[-1]), engine.closed_trades, eq_df["equity"], name)
        results[name] = m

        # Analyze Alt Longs on Bearish BTC
        alt_bear_trades = [c for c in contexts if c["is_alt_long_on_btc_bearish"]]
        tot_ab = len(alt_bear_trades)
        if tot_ab > 0:
            ab_wins = [c for c in alt_bear_trades if c["net_pnl"] > 0]
            ab_win_rate = (len(ab_wins) / tot_ab) * 100.0
            ab_net = sum(c["net_pnl"] for c in alt_bear_trades)
            ab_sl = sum(1 for c in alt_bear_trades if c["exit_reason"] == "SL")
            ab_tp = sum(1 for c in alt_bear_trades if c["exit_reason"] == "TP")
            ab_handoff = sum(1 for c in alt_bear_trades if c["exit_reason"] == "REGIME_HANDOFF")
        else:
            ab_win_rate = 0.0
            ab_net = 0.0
            ab_sl = 0
            ab_tp = 0
            ab_handoff = 0

        alt_breakdowns[name] = {
            "total_alt_bear_trades": tot_ab,
            "win_rate": ab_win_rate,
            "net_pnl": ab_net,
            "tp_count": ab_tp,
            "sl_count": ab_sl,
            "handoff_count": ab_handoff,
        }
        print(f"     Trades: {m['total_trades']}, WinRate: {m['win_rate']:.1f}%, Final Eq: ${m['final_equity']:.2f}, MaxDD: {m['max_drawdown']:.1f}%")
        print(f"     [Alt Longs on BTC Bear]: {tot_ab} trades, Net: ${ab_net:.2f}, WR: {ab_win_rate:.1f}% (TP:{ab_tp}, SL:{ab_sl}, Handoff:{ab_handoff}) in {time.time()-t0:.1f}s")

    # Now test Hybrid with true unified wallet ($300.00 shared) for Baseline vs Exp 1 vs Exp 2
    hybrid_results = {}
    for name, cfg in configs.items():
        print(f"\n---> Testing Unified Hybrid ($300 shared): {name}...")
        t0 = time.time()
        hyb_trades, hyb_eq_df = run_hybrid_unified_wallet(fast_data, sorted_ts, classifier, cfg, initial_capital=Decimal("300.0"))
        m_hyb = compute_metrics(300.0, float(hyb_eq_df["equity"].iloc[-1]), hyb_trades, hyb_eq_df["equity"], f"Hybrid + {name}")
        hybrid_results[name] = m_hyb
        print(f"     Hybrid Trades: {m_hyb['total_trades']}, WR: {m_hyb['win_rate']:.1f}%, Final Eq: ${m_hyb['final_equity']:.2f}, ROI: {m_hyb['net_return_pct']:.1f}%, MaxDD: {m_hyb['max_drawdown']:.1f}% in {time.time()-t0:.1f}s")

    # Save summary report
    out_file = REPO_ROOT / "reports" / "AGGRESSIVE_RANGE_AND_SLIDING_BTC_AUDIT.md"
    with open(out_file, "w", encoding="utf-8") as f:
        f.write("# Quantitative Audit: Aggressive Range Mean-Reversion & Altcoin Buys on Sliding BTC\n\n")
        f.write(f"**Date**: {pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S')}  \n")
        f.write("**Dataset**: Bybit Linear Perpetuals (18 coins), 2024-2026 (24,490+ hourly candles)  \n")
        f.write("**Initial Capital**: $300.00 USDT | **Risk per Range Trade**: 1.0% | **Maker Fee**: 0.0324%\n\n")

        f.write("## 1. Standalone Range Module Performance Comparison\n\n")
        f.write("| Configuration | Trades | Win Rate | Net PnL ($) | ROI (%) | Profit Factor | Max DD (%) | Payoff Ratio |\n")
        f.write("| :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: |\n")
        for name, m in results.items():
            f.write(f"| **{name}** | {m['total_trades']} | {m['win_rate']:.2f}% | ${m['net_profit']:+.2f} | {m['net_return_pct']:+.2f}% | {m['profit_factor']:.2f} | {m['max_drawdown']:.2f}% | {m['payoff_ratio']:.2f} : 1 |\n")

        f.write("\n## 2. Microstructure Analysis: Altcoin Longs During Sliding/Bearish BTC\n\n")
        f.write("What happens when we buy altcoins on the lower Bollinger Band while BTC is sliding?\n\n")
        f.write("| Configuration | Alt Bear Longs | Win Rate | Net PnL ($) | Take Profits | Stop Losses | Regime Handoffs |\n")
        f.write("| :--- | :---: | :---: | :---: | :---: | :---: | :---: |\n")
        for name, b in alt_breakdowns.items():
            f.write(f"| **{name}** | {b['total_alt_bear_trades']} | {b['win_rate']:.2f}% | ${b['net_pnl']:+.2f} | {b['tp_count']} | {b['sl_count']} | {b['handoff_count']} |\n")

        f.write("\n## 3. Dual-Regime Hybrid Portfolio ($300 Unified Wallet)\n\n")
        f.write("| Hybrid Configuration | Total Trades | Win Rate | Final Equity | Net Profit ($) | ROI (%) | Profit Factor | Max DD (%) |\n")
        f.write("| :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: |\n")
        for name, m in hybrid_results.items():
            f.write(f"| **Hybrid + {name}** | {m['total_trades']} | {m['win_rate']:.2f}% | ${m['final_equity']:.2f} | ${m['net_profit']:+.2f} | {m['net_return_pct']:+.2f}% | {m['profit_factor']:.2f} | {m['max_drawdown']:.2f}% |\n")

    print(f"\nAudit completed. Report saved to: {out_file}")


if __name__ == "__main__":
    main()
